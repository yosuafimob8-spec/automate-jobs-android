#!/usr/bin/env python3
"""Apply Update 6 - Kirim Lamaran UI, to the exact 42179122453 base.

The existing API, authorization, CV upload, Gmail OAuth, consent, candidates and
server-confirmed dispatch logic are retained. No commit, push or build.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

BASE_SHA = '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
BASE_SCREEN_BLOB = '715b9e19e891ac5a30e921d441c4e3faccc4359a'
SOURCE = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')
SCREEN = SOURCE / 'KirimLamaranScreen.kt'
HEADER = SOURCE / 'KirimLamaranBrandedHeader.kt'
SHELL = SOURCE / 'MainDashboardScreen.kt'


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def once(source: str, old: str, new: str, what: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'{what}: expected exactly 1 anchor, found {count}; no changes written')
    return source.replace(old, new, 1)


def ui_transform(source: str) -> str:
    # Purely presentation-level imports and semantic colors (night mode safe).
    source = once(source, 'import androidx.compose.material.icons.filled.Schedule\n', '''import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
''', 'Material icon imports')
    source = once(source, 'import com.example.automatesmartbot.ui.theme.KarirTextMuted\n', '''import com.example.automatesmartbot.ui.theme.KarirTextMuted
import com.example.automatesmartbot.ui.theme.ScreenSurface
import com.example.automatesmartbot.ui.theme.screenCanvas
''', 'Screen appearance imports')

    for original, replacement in (
        ('background(KarirPageGradient)', 'background(com.example.automatesmartbot.ui.theme.ScreenPageGradient)'),
        ('containerColor = Color.White', 'containerColor = ScreenSurface'),
        ('color = KarirTextDark', 'color = com.example.automatesmartbot.ui.theme.ScreenText'),
        ('color = KarirTextMuted', 'color = com.example.automatesmartbot.ui.theme.ScreenMuted'),
        ('border = BorderStroke(1.dp, Color(0xFFC6DFE8))', 'border = BorderStroke(1.dp, screenCanvas(Color(0xFFC6DFE8)))'),
    ):
        source = source.replace(original, replacement)

    # Hero text unchanged; enhance its info badge and responsive spacing.
    source = once(source, '"Kirim Lamaran Otomatis",\n                        color =', '"Kirim Lamaran Otomatis",\n                        color =', 'Hero title')
    source = once(source, '''                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFDCFCE7)
                    ) {
                        Text(
                            "Maksimal 5 email per hari • Aman & Tanpa Duplikasi",
                            color = Color(0xFF16A34A),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.5.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
''', '''                    Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFDCFCE7)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Security, null, tint = Color(0xFF079B35),
                                modifier = Modifier.size(19.dp))
                            Text("Maksimal 5 email per hari • Aman & Tanpa Duplikasi",
                                color = Color(0xFF07852F), fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp, lineHeight = 16.sp)
                        }
                    }
''', 'Safe send highlight')

    # Status title icon and real reload action (not a fabricated success state).
    source = once(source, '''                        Text(
                            "Status & Kesiapan",
                            color = com.example.automatesmartbot.ui.theme.ScreenText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        TextButton(
                            onClick = { scope.launch { load() } },
                            enabled = !busy && isOnline
                        ) {
                            Text("Muat Ulang", color = KarirOrangeDeep, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
''', '''                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp),
                            modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Layers, contentDescription = null,
                                tint = Color(0xFF086ABC), modifier = Modifier.size(25.dp))
                            Text("Status & Kesiapan", color = com.example.automatesmartbot.ui.theme.ScreenText,
                                fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                                maxLines = 1)
                        }
                        TextButton(onClick = { scope.launch { load() } },
                            enabled = !busy && isOnline,
                            modifier = Modifier.background(screenCanvas(Color(0xFFE9F5FF)), RoundedCornerShape(13.dp))) {
                            Icon(Icons.Default.Refresh, contentDescription = null,
                                tint = KarirOrangeDeep, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Muat Ulang", color = KarirOrangeDeep,
                                fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        }
''', 'Status heading and reload')

    # Richer status cards without changing data and error conditions.
    source = once(source, '''                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFF7ED),
                            border = BorderStroke(1.dp, Color(0xFFFFD8B2))
                        ) {
                            Text(
                                message,
                                color = Color(0xFF9A3412),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
''', '''                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF7ED),
                            border = BorderStroke(1.dp, Color(0xFFFFD8B2))) {
                            Row(Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Info, contentDescription = null,
                                    tint = Color(0xFFE9900C), modifier = Modifier.size(21.dp))
                                Text(message, color = Color(0xFF9A3412),
                                    fontWeight = FontWeight.Medium, fontSize = 12.sp,
                                    lineHeight = 17.sp, modifier = Modifier.weight(1f))
                            }
                        }
''', 'Error message card')

    # Additional icons on real, functioning buttons.
    source = once(source, '''                        ) {
                            Text("Unggah CV PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
''', '''                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null,
                                modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Unggah CV PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
''', 'Upload CV button')
    source = once(source, '''                        TextButton(onClick = onNavigateProfil) {
                            Text("Profil & CV", color = KarirOrangeDeep, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
''', '''                        TextButton(onClick = onNavigateProfil) {
                            Icon(Icons.Default.Person, contentDescription = null,
                                tint = KarirOrangeDeep, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Profil & CV", color = KarirOrangeDeep,
                                fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
''', 'Profile action button')
    source = once(source, '''                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = KarirOrange)
                        ) {
                            Icon(Icons.Default.Email,''', '''                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = KarirOrange)
                        ) {
                            Icon(Icons.Default.Email,''', 'Gmail button height')

    # Form heading; consent logic and backend operation are unchanged.
    source = once(source, '''                    Text(
                        "Izin & Kontrol Auto Apply",
                        color = com.example.automatesmartbot.ui.theme.ScreenText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
''', '''                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Security, contentDescription = null,
                            tint = Color(0xFF086ABC), modifier = Modifier.size(24.dp))
                        Text("Izin & Kontrol Auto Apply",
                            color = com.example.automatesmartbot.ui.theme.ScreenText,
                            fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
''', 'Controls heading')

    source = once(source, '''        item {
            Text(
                "Kandidat Lamaran",
                color = com.example.automatesmartbot.ui.theme.ScreenText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
''', '''        item {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Groups, contentDescription = null,
                    tint = Color(0xFF086ABC), modifier = Modifier.size(23.dp))
                Text("Kandidat Lamaran", color = com.example.automatesmartbot.ui.theme.ScreenText,
                    fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
''', 'Candidate heading')
    source = once(source, '''        item {
            Text(
                "Riwayat Pengiriman",
                color = com.example.automatesmartbot.ui.theme.ScreenText,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
''', '''        item {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.History, contentDescription = null,
                    tint = Color(0xFF086ABC), modifier = Modifier.size(23.dp))
                Text("Riwayat Pengiriman", color = com.example.automatesmartbot.ui.theme.ScreenText,
                    fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
''', 'Delivery heading')

    # Verify that every sensitive backend action is present and unchanged in meaning.
    for operation in (
        'getAutoApplyStatus()', 'getMe()', 'getKarirMateCandidates()',
        'getKarirMateReport()', 'uploadAutoApplyCv(', 'startGmailOAuth()',
        'enableAutoApply(', 'pauseAutoApply()', 'AutoApplyConfirmation.sent(',
        'gmailConnected && cvUploaded && isPro',
    ):
        if operation not in source:
            raise RuntimeError(f'Required real backend flow missing after styling: {operation}')
    return source


def header_route(shell: str) -> str:
    marker = '} else if (edgeHeader) {'
    return once(shell, marker, '''} else if (currentRoute == Screen.KirimLamaran.route) {
                    KirimLamaranBrandedHeader(isPro = isPro,
                        onBack = onBack ?: navigateUpOrDashboard)
                } else if (edgeHeader) {''', 'MainDashboard header route')


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path, help='Local clone on exact verified base')
    p.add_argument('--check', action='store_true', help='Validate compatibility only')
    args = p.parse_args()
    root = args.repository.resolve()
    if not (root / '.git').is_dir():
        raise RuntimeError('Destination must be a Git clone')
    head = git(root, 'rev-parse', 'HEAD')
    if head != BASE_SHA:
        raise RuntimeError(f'Expected base {BASE_SHA}, got {head}. No writes.')
    for rel in (SCREEN, SHELL):
        if not (root / rel).is_file():
            raise RuntimeError(f'Missing {rel}')
    if (root / HEADER).exists():
        raise RuntimeError(f'New header already exists: {HEADER}')
    if git(root, 'hash-object', str(root / SCREEN)) != BASE_SCREEN_BLOB:
        raise RuntimeError('KirimLamaranScreen.kt modified against base, will not overwrite')
    bundled = Path(__file__).resolve().parent / 'files' / HEADER
    if not bundled.is_file():
        raise RuntimeError('Missing bundled Kotlin header')
    screen = (root / SCREEN).read_text(encoding='utf-8')
    shell = (root / SHELL).read_text(encoding='utf-8')
    new_screen = ui_transform(screen)
    new_shell = header_route(shell)
    assert new_shell.count('KirimLamaranBrandedHeader(') == 1
    assert new_screen.count('startGmailOAuth()') == screen.count('startGmailOAuth()')
    assert new_screen.count('enableAutoApply(') == screen.count('enableAutoApply(')
    assert new_screen.count('pauseAutoApply()') == screen.count('pauseAutoApply()')
    if args.check:
        print('PASS Update 6: base, original API integration, header route and targeted UI changes; no writes')
        return
    (root / SCREEN).write_text(new_screen, encoding='utf-8')
    (root / SHELL).write_text(new_shell, encoding='utf-8')
    shutil.copy2(bundled, root / HEADER)
    print('Applied Update 6 locally. No commit, push, workflow dispatch, Gradle or APK build.')
    print(git(root, 'status', '--short', '--', str(SCREEN), str(HEADER), str(SHELL)))


if __name__ == '__main__':
    try:
        main()
    except (OSError, AssertionError, RuntimeError, subprocess.CalledProcessError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
