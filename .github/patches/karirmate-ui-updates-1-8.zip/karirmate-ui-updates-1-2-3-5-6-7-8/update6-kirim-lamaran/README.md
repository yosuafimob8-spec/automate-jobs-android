# KarirMate — Update 6: Kirim Lamaran (UI)

**Verified base:** GitHub Actions run `42179122453` at commit
`1b4c04b6e3d13196b927d556a4394ae21f0a3a42` on branch
`integration/base41860101825-ui-merge-20261105`.

## UI changes

- Single full-width blue-to-turquoise branded header (status bar integrated): back button, **K** logo, divider, title **Kirim Lamaran**, subtitle, and genuine **PRO**/**FREE** badge. Replaces the generic page top bar for **Kirim Lamaran only**; no duplicated header.
- Main scrollable body follows provided reference: program-intro banner and green 5-email safety ribbon; Status & Kesiapan with reload and real error messages; CV PDF upload, Profile & CV and Gmail OAuth actions; Auto Apply consent/pause controls; Kandidat Lamaran and Riwayat Pengiriman sections.
- Cleaner icons and padding, blue actions, theme-aware card and text colors.
- Real backend API calls, OAuth allowlist, 5-email messaging, explicit consent, PRO gates, PDF size/type verification and server-confirmed delivery semantics **remain in the original screen**.
- Status `409` remains an error until the server reports otherwise; no fake sent state or fake candidates.

## Apply manually to a LOCAL working copy

The patch is intentionally NOT applied to the remote GitHub repository. Use a local Git clone checked out at the exact base commit, and run:

```bash
python3 /path/to/karirmate-update6-kirim-lamaran/apply_update6.py "$PWD" --check
python3 /path/to/karirmate-update6-kirim-lamaran/apply_update6.py "$PWD"
```

`--check` inspects patch compatibility and **does not modify** anything. The apply command writes changes only to the local working tree, **without** Git commit, push, workflow dispatch or Gradle/APK build.

Changes: `KirimLamaranScreen.kt` (UI only), `MainDashboardScreen.kt` (route to dedicated header) and new `KirimLamaranBrandedHeader.kt`.

**Validation:** Python patch script compiles; source anchors and API names are preflighted when applied. Android compile/emulator screenshot/pixel-perfect matching are NOT claimed or performed as user requested no APK build.
