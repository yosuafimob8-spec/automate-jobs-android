# KarirMate — Update 8: badge FREE/PRO membaca status keanggotaan asli

**Base tetap:** GitHub Actions run `42179122453` / commit `1b4c04b6e3d13196b927d556a4394ae21f0a3a42`.

**Tidak melakukan push GitHub, commit Git, workflow dispatch, atau build APK.**

## Masalah yang ditemukan di source

Beberapa badge akun sebelumnya menampilkan PRO secara konstan, termasuk Dashboard,
AI Interview, pelatihan, `CareerEdgeHeader`, dan header tambahan pada paket
Update 1–7. Dashboard juga membaca `isPro` tanpa selalu mengecek `membershipVerified`.

## Perbaikan

- Satu komponen `MembershipBadge.kt` untuk seluruh indikator **status akun**.
- `PRO`: hanya saat `GET /me` mengonfirmasi hak PRO yang diverifikasi.
- `FREE`: hanya saat backend mengonfirmasi akun FREE.
- `CEK`: saat offline, belum login, respons tanpa klaim status, atau status belum berhasil diverifikasi. **Tidak dianggap FREE/PRO**.
- Bila masa kedaluwarsa dikirim dengan format ISO 8601 dan sudah lewat, akses PRO ditolak.
- Memuat ulang status saat aplikasi kembali aktif dan setiap 60 detik selagi sesi hidup.
- Memutus respons lama ketika logout atau berganti akun supaya badge tidak salah akun.
- **PRO DEMO tidak memengaruhi badge akun/otorisasi.** PRO yang dicetak sebagai *nama fitur / harga paket / label konten PRO* dibiarkan apa adanya, bukan badge status anggota.
- Menjaga tata letak header referensi lama; yang diganti hanya indikator akun di dalamnya.

## Lokasi indikator yang diaudit dan diperbaiki

1. `DashboardScreen.kt` (badge Dashboard + proteksi `isPro`)
2. `AppTopBar.kt` (header umum)
3. `CareerEdgeHeader.kt` (header bergaya biru)
4. `AiInterviewLanding.kt` (header AI Interview)
5. `PsychotestHome.kt` (status anggota pada landing Psikotes)
6. `JobTrainingScreen.kt` (header internal Pelatihan/Sertifikat)
7. `PromoScreen.kt` (status member halaman promosi jika dipakai)
8. `KirimLamaranScreen.kt` (label KARIRMATE • PRO sebelumnya permanen)
9. `ProBrandedHeader.kt` (dari Update 1)
10. `HistoryBrandedHeader.kt` (dari Update 3)
11. `CertificateHistoryBody.kt` (badge di body; **header luar Sertifikat tidak diganti desainnya**)
12. `KirimLamaranBrandedHeader.kt` (dari Update 6)
13. `CareerLettersBrandedHeader.kt` (dari Update 7)

Sentral status: `MainDashboardScreen.kt`, `DashboardViewModel`, `AuthModels.kt`.

## Cara menerapkan

Paling aman gunakan paket **gabungan Update 1, 2, 3, 5, 6, 7, 8**.

Untuk patch ini saja, jalankan **setelah** Update 1–7 diaplikasikan pada clone lokal
berbasis commit yang persis sama:

```bash
python3 apply_update8.py /lokasi/clone/karirmate --check
python3 apply_update8.py /lokasi/clone/karirmate
```

`--check` adalah pemeriksaan statis tanpa menulis file. Patch menolak commit dasar berbeda dan bertujuan mencegah penimpaan perubahan lain.

## Catatan validasi

Unit test baru: `MembershipBadgeTest.kt` (3 kasus) dan `MembershipExpiryTest.kt` (3 kasus).
**Belum dijalankan Gradle, tidak ada build APK atau pengujian emulator.**
Keberhasilan kompilasi dan kemiripan visual final belum diklaim.
