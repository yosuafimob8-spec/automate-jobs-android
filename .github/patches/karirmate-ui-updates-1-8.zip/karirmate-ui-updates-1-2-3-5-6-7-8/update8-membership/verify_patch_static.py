#!/usr/bin/env python3
"""Lightweight static checks for Update 8: no Gradle, no Android build."""
from pathlib import Path
import importlib.util

root = Path(__file__).parent
spec = importlib.util.spec_from_file_location('u8', root / 'apply_update8.py')
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.BASE == '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
for rel in ('app/src/main/java/com/example/automatesmartbot/ui/components/MembershipBadge.kt',
            'app/src/test/java/com/example/automatesmartbot/ui/components/MembershipBadgeTest.kt',
            'app/src/test/java/com/example/automatesmartbot/data/model/MembershipExpiryTest.kt'):
    src = (root / 'files' / rel).read_text()
    assert src.count('{') == src.count('}'), rel
    assert src.startswith('package com.example.automatesmartbot.')
assert 'MembershipTier.UNVERIFIED' in (root/'files/app/src/main/java/com/example/automatesmartbot/ui/components/MembershipBadge.kt').read_text()
print('PASS: Python patcher syntax, new Kotlin file packaging and structural checks')
