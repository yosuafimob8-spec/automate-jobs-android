#!/usr/bin/env python3
"""Update 8: replace all account membership badges with server-verified state.

Apply to a local clone of exact GitHub Actions run 42179122453, preferably
AFTER Updates 1, 2, 3, 5, 6, 7. Never commits, pushes, triggers a workflow or builds.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess
import sys

BASE = '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
PREFIX = Path('app/src/main/java/com/example/automatesmartbot')
SCREENS = PREFIX / 'ui/screens'
COMPONENTS = PREFIX / 'ui/components'
MODEL = PREFIX / 'data/model'
TESTS = Path('app/src/test/java/com/example/automatesmartbot/ui/components')


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def replace_once(s: str, old: str, new: str, label: str) -> str:
    count = s.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected exactly 1 occurrence, found {count}')
    return s.replace(old, new, 1)


def replace_between(s: str, first: str, after: str, new: str, label: str) -> str:
    if s.count(first) != 1 or s.count(after) != 1:
        raise ValueError(f'{label}: expected unique anchors ({s.count(first)}, {s.count(after)})')
    a = s.index(first)
    b = s.index(after, a)
    if b <= a:
        raise ValueError(f'{label}: anchors reversed')
    return s[:a] + new + s[b:]


def replace_surface_containing(s: str, phrase: str, label: str, style='HEADER', prefix='                ') -> str:
    if s.count(phrase) != 1:
        raise ValueError(f'{label}: expected unique text anchor {phrase}, found {s.count(phrase)}')
    pos = s.index(phrase)
    start = s.rfind('Surface(', 0, pos)
    if start == -1 or pos - start > 1400:
        raise ValueError(f'{label}: could not identify badge Surface')
    brace = s.find('{', start)
    if brace < 0 or brace > pos:
        raise ValueError(f'{label}: Surface opening brace not found')
    depth = 0
    close = None
    for i in range(brace, len(s)):
        if s[i] == '{': depth += 1
        elif s[i] == '}':
            depth -= 1
            if depth == 0:
                close = i + 1
                break
    if close is None or close <= pos:
        raise ValueError(f'{label}: Surface unbalanced')
    return s[:start] + f'com.example.automatesmartbot.ui.components.MembershipBadge(style = com.example.automatesmartbot.ui.components.MembershipBadgeStyle.{style})' + s[close:]


def transform_shell(s: str) -> str:
    s = replace_once(
        s,
        '    val isPro = dashboardStatus?.isPro == true && dashboardStatus?.membershipVerified == true',
        '    val isPro = dashboardStatus?.isPro == true && dashboardStatus?.membershipVerified == true\n'
        '    val currentMembershipTier = com.example.automatesmartbot.ui.components.membershipTier(dashboardStatus)',
        'MainDashboard membership tier'
    )
    old = '''            if (event == Lifecycle.Event.ON_RESUME &&
                sessionToken != null &&
                sessionManager?.hasValidSession() != true
            ) {
                endSession()
            }'''
    new = '''            if (event == Lifecycle.Event.ON_RESUME && sessionToken != null) {
                if (sessionManager?.hasValidSession() != true) endSession()
                else dashboardViewModel.loadStatus() // Refresh after payment, expiration, or account changes.
            }'''
    s = replace_once(s, old, new, 'Refresh on resume')
    old_login = '''                            val newToken = sessionManager?.getValidToken()
                            sessionToken = newToken'''
    new_login = '''                            val newToken = sessionManager?.getValidToken()
                            dashboardViewModel.reset() // Do not display the previous account's membership.
                            sessionToken = newToken'''
    s = replace_once(s, old_login, new_login, 'Clear old membership on login')
    # Keep status current when the app remains in the foreground for a long time.
    anchor = '''    val isPro = dashboardStatus?.isPro == true && dashboardStatus?.membershipVerified == true'''
    timer = '''    LaunchedEffect(sessionToken) {
        if (sessionToken.isNullOrBlank()) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(60_000L)
            if (sessionManager?.hasValidSession() != true) return@LaunchedEffect
            dashboardViewModel.loadStatus()
        }
    }

'''
    s = replace_once(s, anchor, timer + anchor, 'Foreground periodic verification')
    s = replace_once(
        s,
        '    Scaffold(\n        topBar = {',
        '    androidx.compose.runtime.CompositionLocalProvider(\n'
        '        com.example.automatesmartbot.ui.components.LocalMembershipTier provides currentMembershipTier\n'
        '    ) {\n'
        '    Scaffold(\n        topBar = {',
        'App shell membership injection'
    )
    # MainDashboardContent is the last function in this source file.
    if not s.endswith('    }\n}\n'):
        raise ValueError('MainDashboard end-of-function shape changed; review manually')
    s = s[:-2] + '    }\n}\n'
    return s


def transform_dashboard(s: str) -> str:
    s = replace_once(s, 'val isPro = status?.isPro == true',
                     'val isPro = status?.isPro == true && status?.membershipVerified == true',
                     'Dashboard eligibility')
    start = '                    // PRO Badge Pill\n'
    end = '                    // Notification Bell'
    s = replace_between(s, start, end,
        '''                    // The badge reflects verified account status, not a static PRO icon.
                    com.example.automatesmartbot.ui.components.MembershipBadge(
                        modifier = Modifier.clickable { onNavigate(Screen.Profil.route) },
                        style = com.example.automatesmartbot.ui.components.MembershipBadgeStyle.SOLID
                    )

''', 'Dashboard PRO badge')
    return s


def transform_topbar(s: str) -> str:
    return replace_between(s, '            // Membership Status Badge\n',
        '            Spacer(modifier = Modifier.width(8.dp))',
        '            com.example.automatesmartbot.ui.components.MembershipBadge(\n'
        '                style = com.example.automatesmartbot.ui.components.MembershipBadgeStyle.LIGHT\n'
        '            )\n\n', 'Global app top bar')


def transform_promo(s: str) -> str:
    # The promo page does not have an app-shell route today, but it must never
    # imply a verified FREE membership when the backend claim is unavailable.
    s = replace_once(s,
        'text = if (isPro) "PRO MEMBER ⭐" else "FREE MEMBER",',
        'text = when (com.example.automatesmartbot.ui.components.LocalMembershipTier.current) {\n'
        '                    com.example.automatesmartbot.ui.components.MembershipTier.PRO -> "PRO MEMBER ⭐"\n'
        '                    com.example.automatesmartbot.ui.components.MembershipTier.FREE -> "FREE MEMBER"\n'
        '                    else -> "STATUS BELUM DIVERIFIKASI"\n'
        '                },', 'Promo membership text')
    s = replace_once(s,
        'text = if (isPro) "Status Aktif" else "Belum Upgrade",',
        'text = when (com.example.automatesmartbot.ui.components.LocalMembershipTier.current) {\n'
        '                    com.example.automatesmartbot.ui.components.MembershipTier.PRO -> "Status Aktif"\n'
        '                    com.example.automatesmartbot.ui.components.MembershipTier.FREE -> "Belum Upgrade"\n'
        '                    else -> "Menunggu verifikasi akun"\n'
        '                },', 'Promo membership status')
    return s


def transform_models(s: str) -> str:
    original = '''    val hasProMembership: Boolean
        get() = isPro ?: (membership?.equals("pro", ignoreCase = true) == true)'''
    updated = '''    /** The backend is authoritative; a parseable expired date can never unlock PRO. */
    val hasProMembership: Boolean
        get() {
            val serverGrantsPro = isPro ?: (membership?.equals("pro", ignoreCase = true) == true)
            if (!serverGrantsPro) return false
            val expiry = membershipExpiresAt?.takeIf { it.isNotBlank() }?.let { value ->
                runCatching { java.time.Instant.parse(value).toEpochMilli() }.getOrNull()
                    ?: runCatching { java.time.OffsetDateTime.parse(value).toInstant().toEpochMilli() }.getOrNull()
            }
            return expiry == null || expiry > System.currentTimeMillis()
        }'''
    return replace_once(s, original, updated, 'Membership expiry check')


def transform_viewmodel(s: str) -> str:
    s = replace_once(s, 'class DashboardViewModel(\n    private val repository: DashboardRepository = DashboardRepository()\n) : ViewModel() {',
        'class DashboardViewModel(\n    private val repository: DashboardRepository = DashboardRepository()\n) : ViewModel() {\n    private var membershipRequestVersion = 0',
        'Membership request version')
    old = '''    fun loadStatus() {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.getDashboardStatus()
            _status.value = result.getOrNull()
            _isLoading.value = false
        }
    }

    fun reset() {
        _status.value = null
    }'''
    new = '''    fun loadStatus() {
        val requestVersion = ++membershipRequestVersion
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.getDashboardStatus()
            if (requestVersion == membershipRequestVersion) {
                _status.value = result.getOrNull()
                _isLoading.value = false
            }
        }
    }

    fun reset() {
        membershipRequestVersion++ // Reject any in-flight status reply for the old account.
        _status.value = null
        _isLoading.value = false
    }'''
    return replace_once(s, old, new, 'Clear stale membership requests')


def apply_patch(root: Path, check: bool) -> None:
    if not (root / '.git').exists():
        raise ValueError('Destination must be a local Git clone')
    sha = git(root, 'rev-parse', 'HEAD')
    if sha != BASE:
        raise ValueError(f'Wrong base commit {sha}; expected {BASE}')
    here = Path(__file__).resolve().parent
    bundle = here / 'files'
    new_files = [COMPONENTS / 'MembershipBadge.kt', TESTS / 'MembershipBadgeTest.kt', Path('app/src/test/java/com/example/automatesmartbot/data/model/MembershipExpiryTest.kt')]
    for rel in new_files:
        if not (bundle / rel).is_file() or (root / rel).exists():
            raise ValueError(f'Missing patch or target already exists: {rel}')

    plans: list[tuple[Path, str]] = []
    def plan(rel: Path, transform) -> None:
        file = root / rel
        if not file.is_file():
            raise ValueError(f'Missing required app file: {rel}')
        src = file.read_text(encoding='utf8')
        dest = transform(src)
        if src == dest:
            raise ValueError(f'No changes in: {rel}')
        plans.append((rel, dest))

    plan(SCREENS / 'MainDashboardScreen.kt', transform_shell)
    plan(SCREENS / 'DashboardScreen.kt', transform_dashboard)
    plan(COMPONENTS / 'AppTopBar.kt', transform_topbar)
    plan(SCREENS / 'CareerEdgeHeader.kt', lambda s: replace_surface_containing(s,
        'Text(if (isPro) "PRO" else "PRO"', 'CareerEdgeHeader'))
    plan(SCREENS / 'AiInterviewLanding.kt', lambda s: replace_surface_containing(s,
        'if (isPro) "★ PRO" else "♛ PRO"', 'AI Interview header'))
    plan(SCREENS / 'JobTrainingScreen.kt', lambda s: replace_surface_containing(s,
        '"♛ PRO"', 'Pelatihan header', style='LIGHT'))
    plan(SCREENS / 'PsychotestHome.kt', lambda s: replace_surface_containing(s,
        'Text(if (isPro) "♛ PRO Aktif" else "♛ PRO"', 'Psikotes header', style='LIGHT'))
    plan(SCREENS / 'PromoScreen.kt', transform_promo)
    # Hero account label in Kirim Lamaran was hardcoded to PRO even for FREE users.
    plan(SCREENS / 'KirimLamaranScreen.kt', lambda s: replace_once(s,
        '"KARIRMATE • PRO",',
        '''"KARIRMATE • " + when (com.example.automatesmartbot.ui.components.LocalMembershipTier.current) {
                                    com.example.automatesmartbot.ui.components.MembershipTier.PRO -> "PRO"
                                    com.example.automatesmartbot.ui.components.MembershipTier.FREE -> "FREE"
                                    else -> "CEK"
                                },''',
        'Kirim Lamaran account label'))
    plan(MODEL / 'AuthModels.kt', transform_models)
    plan(PREFIX / 'ui/viewmodel/ViewModels.kt', transform_viewmodel)
    # Headers from earlier patches. They are checked after applying 1–7, not required on a pristine base --check.
    custom = [
        ('ProBrandedHeader.kt', 'Text("PRO",'),
        ('HistoryBrandedHeader.kt', 'Text("PRO",'),
        ('KirimLamaranBrandedHeader.kt', 'Text(if (isPro) "PRO" else "FREE"'),
        ('CareerLettersBrandedHeader.kt', 'Text(if (isPro) "PRO" else "FREE"'),
    ]
    for name, marker in custom:
        rel = SCREENS / name
        if (root / rel).exists():
            plan(rel, lambda src, marker=marker, name=name: replace_surface_containing(src, marker, name))
        elif not check:
            raise ValueError(f'Expected Updates 1–7 before Update 8: {rel} missing')
    certificate = SCREENS / 'CertificateHistoryBody.kt'
    if (root / certificate).exists():
        plan(certificate, lambda src: replace_surface_containing(src, 'Text("PRO",',
            'Certificate requirement member badge', style='LIGHT'))
    elif not check:
        raise ValueError('Update 5 is required before updating certificate status badge')
    # Full preflight above; no file mutations until all transformations succeed.
    if check:
        print(f'PASS Update 8 preflight: {len(plans)} existing files checked, {len(new_files)} new files validated; no writes.')
        return
    for rel, content in plans:
        (root / rel).write_text(content, encoding='utf8')
    for rel in new_files:
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(bundle / rel, dst)
    print(f'Applied Update 8 locally: {len(plans)} source updates and {len(new_files)} new files.')
    print('No GitHub push, no commit, no Gradle, no APK build.')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository', type=Path)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    apply_patch(args.repository.resolve(), args.check)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
