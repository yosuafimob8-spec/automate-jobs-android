# KarirMate — Update 2 / WorkPedia UI Card Redesign

Base APK/source from GitHub Actions run `42179122453` (branch
`integration/base41860101825-ui-merge-20261105`, commit
`1b4c04b6e3d13196b927d556a4394ae21f0a3a42`).

## Scope

Only WorkPedia's *list of terms* changes. Screen header, search,
category filters, favorites, detail page, 70-term JSON and bottom navigation
are not removed or reworked.

- New polished cards with category-specific accent strip and icon, strong title,
  informative quick-definition preview (2–3 lines), category chip,
  `Baca detail` CTA and a separate favorite star.
- PKWT and PKWTT show their actual expansions instead of repeating the acronym.
- Tapping the card opens the existing full detail page; tapping the star changes
  the persistent favorite set. Respects the current light/dark theme.
- No data fabricated for the other terms; preview derives from their JSON definition.

## Apply locally (no push/build)

Check out exactly base commit `1b4c04b6` in your local clone, or use the
working tree with Update 1 (PRO UI redesign) already applied and HEAD
still at the same base commit. From that clone:

```bash
python3 /path/to/karirmate-workpedia-update2/apply_update2.py "$PWD" --check
python3 /path/to/karirmate-workpedia-update2/apply_update2.py "$PWD"
```

Refuses mismatched base file, unexpected card markup or a dirty WorkPedia
source. **Never pushes, commits, triggers workflows, or builds APK.**

## Validation

Code patch validated structurally; Android compile and visual comparison not
performed pending explicit authorization to build. Update 1 stays separate;
this patch can be applied after it without overwriting it.
