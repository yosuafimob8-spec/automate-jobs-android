#!/usr/bin/env python3
"""Apply the WorkPedia card redesign locally, without push, commit or build.

Works against the exact Actions 42179122453 base, either pristine or after Update 1.
"""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

BASE_SHA = "1b4c04b6e3d13196b927d556a4394ae21f0a3a42"
SCREEN = Path("app/src/main/java/com/example/automatesmartbot/ui/screens/WorkPediaScreen.kt")
NEW = Path("app/src/main/java/com/example/automatesmartbot/ui/screens/WorkPediaTermCard.kt")
BASE_FILE_BLOB_SHA = "6a604e1f73be9e585aac3824cabf1517fd87a1c3"
START = '                    items(visible, key = { it.optString("id") }) { term ->\n'
END = '                }\n            } else {\n                val term = entries.firstOrNull { it.optString("id") == selected }'
REPLACEMENT = '''                    items(visible, key = { it.optString("id") }) { term ->
                        val id = term.optString("id")
                        WorkPediaTermCard(
                            term = term,
                            isFavorite = id in favorites,
                            onOpen = { selected = id },
                            onFavoriteToggle = {
                                favorites = if (id in favorites) favorites - id else favorites + id
                                prefs.edit().putStringSet("ids", favorites.toSet()).apply()
                            }
                        )
                    }
'''


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def patch(original: str) -> str:
    if original.count(START) != 1 or original.count(END) != 1:
        raise RuntimeError("WorkPediaScreen.kt: expected listing markers not found exactly once")
    a = original.index(START)
    b = original.index(END, a)
    old_cards = original[a:b]
    required = [
        "Card(", 'onClick = { selected = term.optString("id") }',
        'term.optString("fullName")',
        'prefs.edit().putStringSet("ids", favorites).apply()'
    ]
    for item in required:
        if item not in old_cards:
            raise RuntimeError("WorkPediaScreen.kt: unexpected source at original cards: " + item)
    return original[:a] + REPLACEMENT + original[b:]


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("repository", type=Path)
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    root = args.repository.resolve()
    if not (root / ".git").exists():
        raise RuntimeError("Destination is not a Git repository")
    if git(root, "rev-parse", "HEAD") != BASE_SHA:
        raise RuntimeError("Wrong base commit (expected " + BASE_SHA + ")")
    src = root / SCREEN
    dst = root / NEW
    bundled = Path(__file__).resolve().parent / "files" / NEW
    if not src.is_file() or not bundled.is_file() or dst.exists():
        raise RuntimeError("Source missing, package missing or new WorkPediaTermCard.kt already exists")
    if git(root, "hash-object", str(src)) != BASE_FILE_BLOB_SHA:
        raise RuntimeError("WorkPediaScreen.kt no longer matches the verified base")
    content = patch(src.read_text(encoding="utf-8"))
    if args.check:
        print("PASS: verified base, WorkPedia listing compatible, add-on present; no writes")
        return
    if git(root, "status", "--porcelain", "--", str(SCREEN)):
        raise RuntimeError("WorkPediaScreen.kt has uncommitted changes; refusing to overwrite")
    src.write_text(content, encoding="utf-8")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(bundled, dst)
    print("APPLIED: Update 2 — WorkPedia term cards (local only)")
    print("No push, no commit, no Gradle build")
    print(git(root, "status", "--short", "--", str(SCREEN), str(NEW)))


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError) as err:
        print("ERROR:", err, file=sys.stderr)
        sys.exit(1)
