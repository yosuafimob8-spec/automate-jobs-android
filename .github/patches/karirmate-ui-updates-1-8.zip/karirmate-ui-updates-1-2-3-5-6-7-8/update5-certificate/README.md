# UPDATE 5 — Riwayat Sertifikat (BODY ONLY)

Base: GitHub Actions run **42179122453**, commit
`1b4c04b6e3d13196b927d556a4394ae21f0a3a42`,
branch `integration/base41860101825-ui-merge-20261105`.

**REQUEST LOCK: DO NOT CHANGE THE HEADER.** This update does not touch
`CareerEdgeHeader.kt`, `AppTopBar.kt`, the navigation shell, or any status bar settings.
Only the `"history"` BODY branch inside `JobTrainingScreen.kt` is replaced,
and `CertificateHistoryBody.kt` is added. Other training stages are untouched.

## Body design
- Heading `Riwayat Sertifikat` with medal illustration.
- `Syarat Mendapatkan Sertifikat` premium-layout card, with truthful current statuses.
- `Sertifikat Terbaru` card with preview of the certificate's actual artwork,
  participant name/date/ID, and working Lihat Sertifikat, Unduh PDF and Bagikan actions.
- `Verifikasi Sertifikat` card checks full QR payload against locally recorded
  certificates, explicitly does not claim online validation.
- `Kembali ke Katalog` and a list of other certificates (when they exist).
- Keeps existing bottom navigation, dark/light color adaptation, existing certificate
  data, and existing exported PDF art. No mock certificate records are introduced.

`Lolos Psikotes` and `Lolos Interview AI` must *not* be pre-marked as passed:
these modules do not provide a verified cross-module completion record in this base.
One local training certificate does not imply a full competency certification or BNSP
accreditation.

## Apply (local only)

From the clean exact-base clone (may already have Updates 1–3 uncommitted):

```sh
python3 /path/to/karirmate-update5-certificate/apply_update5.py "$PWD" --check
python3 /path/to/karirmate-update5-certificate/apply_update5.py "$PWD"
```

This patch explicitly guards the base commit, original training file hash,
and distinct body anchor. It will refuse to overwrite unknown edits.

**No push / no git commit / no Gradle / no build**. Static source review only;
compilation and device/pixel fidelity have not been tested, per instruction.
