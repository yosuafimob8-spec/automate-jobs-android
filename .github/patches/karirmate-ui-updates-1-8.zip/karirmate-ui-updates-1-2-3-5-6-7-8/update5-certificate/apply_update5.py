#!/usr/bin/env python3
"""Apply Update 5 (certificate HISTORY BODY only) to KarirMate base 42179122453.

No GitHub writes, commits, Gradle or builds. Header/navigation are never edited.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

BASE_COMMIT = '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
BASE_TRAINING_BLOB = 'ce97b92893b51041d389d09e2e9a2238ace708ec'
SOURCE_DIR = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')
TARGET = SOURCE_DIR / 'JobTrainingScreen.kt'
ADDITION = SOURCE_DIR / 'CertificateHistoryBody.kt'
START = '                "history" -> {\n                    val history = JSONArray(prefs.getString("certificates", "[]"))'
END = '\n                }\n            }\n        }\n    }\n    }\n    }\n}'
INSERT = '''                "history" -> {
                    val history = JSONArray(prefs.getString("certificates", "[]"))
                    CertificateHistoryBody(
                        history = history,
                        onShowCertificate = { item -> certificate = item; stage = "certificate" },
                        onBackToCatalog = { stage = "catalog" }
                    )
'''

def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def transform(text: str) -> str:
    if text.count(START) != 1:
        raise RuntimeError('Certificate history start anchor missing or repeated')
    i = text.index(START)
    j = text.find(END, i)
    if j == -1:
        raise RuntimeError('Certificate history end anchor missing; source layout changed')
    fragment = text[i:j]
    required = (
        'TrainingCertificateIdentity.verifyLocal',
        '★ Sertifikat Terbaru',
        '"Syarat Mendapatkan Sertifikat"',
    )
    if any(x not in fragment for x in required):
        raise RuntimeError('Base history body differs from inspected version')
    out = text[:i] + INSERT + text[j:]
    if out.count('CertificateHistoryBody(') != 1:
        raise RuntimeError('New body must be referenced exactly once')
    if 'CareerEdgeHeader(' in out and 'CareerEdgeHeader(' not in text:
        raise RuntimeError('Unexpected header update detected')
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path, help='Local Git clone checked out at exact base commit')
    p.add_argument('--check', action='store_true', help='Validate without writing files')
    args = p.parse_args()
    root = args.repository.resolve()
    if not (root / '.git').exists():
        raise RuntimeError('Destination must be a Git repository clone')
    head = git(root, 'rev-parse', 'HEAD')
    if head != BASE_COMMIT:
        raise RuntimeError(f'Base mismatch: expected {BASE_COMMIT}, found {head}')
    src = root / TARGET
    if not src.exists():
        raise RuntimeError(f'Missing source file: {TARGET}')
    if git(root, 'hash-object', str(src)) != BASE_TRAINING_BLOB:
        raise RuntimeError('JobTrainingScreen source differs from base; merge manually, no overwrite')
    if (root / ADDITION).exists():
        raise RuntimeError(f'Refusing to overwrite an existing file: {ADDITION}')
    bundled = Path(__file__).resolve().parent / 'files' / ADDITION
    if not bundled.is_file():
        raise RuntimeError('Bundled certificate body Kotlin file is missing')
    current = src.read_text(encoding='utf-8')
    updated = transform(current)
    # Verify all content OUTSIDE the history branch is identical (the header is untouched).
    assert updated.split('                "history" -> {', 1)[0] == current.split('                "history" -> {', 1)[0]
    assert updated.endswith(END.lstrip('\n')) == current.endswith(END.lstrip('\n'))
    if args.check:
        print('PASS Update 5: exact base, preserved header, single certificate body replacement. No writes.')
        return
    src.write_text(updated, encoding='utf-8')
    shutil.copy2(bundled, root / ADDITION)
    print('Applied Update 5 certificate BODY only, in local clone. Header unchanged.')
    print('GitHub push: NO | Git commit: NO | APK build: NO')
    print(git(root, 'status', '--short', '--', str(TARGET), str(ADDITION)))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError, AssertionError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
