# UPDATE 3 - Riwayat Lamaran

**Base**: GitHub Actions Run `42179122453` / commit
`1b4c04b6e3d13196b927d556a4394ae21f0a3a42`, branch
`integration/base41860101825-ui-merge-20261105`.

Changes are local-only until the owner approves GitHub push and APK build.

## Scope

- Replace the existing white app toolbar with a single blue/teal **HistoryBrandedHeader**,
  using the real Android status bar, logo, back button, divider, title, subtitle and gold PRO badge.
- Keep an informational hero with document/lock artwork beneath the header; this is **not**
  a second top navigation bar.
- Add a collapsible Info card, Status Pengiriman card with Muat Ulang control, and
  a full-size document/clock empty-state illustration.
- Retain all five bottom navigation destinations.
- Do **not** invent delivery history. The base `RiwayatScreen` has no authenticated
  history repository. Refresh shows a truthful notice until a genuine source is wired.
- Adapt the cards to the selected app light/dark color mode.

## Apply to your checkout

From the repository checkout at the exact base commit:

```bash
python3 /path/to/update3-history/apply_update3.py "$PWD" --check
python3 /path/to/update3-history/apply_update3.py "$PWD"
```

Can be applied to the pristine base or after Update 1. To combine all updates,
apply **1 -> 2 -> 3** with `apply_all.py` in the combined package.

Never overwrites an already edited RiwayatScreen or a non-matching MainDashboardScreen.
No git commit, push, Gradle, or APK build is performed.

**Validation**: script syntax, source matching and header routing static checks only;
visual device comparison and Android compilation **not** yet performed.
