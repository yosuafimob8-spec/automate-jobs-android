#!/usr/bin/env python3
"""Apply Update 3 - Riwayat Lamaran UI to the verified GitHub Actions base.

Can be run on pristine base or AFTER Update 1. Does not commit, push or build.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

BASE_SHA = '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
BASE_SCREEN_BLOB = 'eee6b3a992e2d0d8b5fde6a34e41c6aae0ddb382'
SOURCE = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')
SCREEN = SOURCE / 'RiwayatScreen.kt'
HEADER = SOURCE / 'HistoryBrandedHeader.kt'
SHELL = SOURCE / 'MainDashboardScreen.kt'
BASE_TOP = 'if (showTopBar) {\n                if (edgeHeader) {'
UPDATE_1_TOP = ('if (showTopBar) {\n'
                '                if (currentRoute == Screen.UpgradePro.route) {\n'
                '                    ProBrandedHeader(onBack = onBack ?: navigateUpOrDashboard)\n'
                '                } else if (edgeHeader) {')
HISTORY_BRANCH = ('if (currentRoute == Screen.Riwayat.route) {\n'
                  '                    HistoryBrandedHeader(onBack = onBack ?: navigateUpOrDashboard)\n'
                  '                } else if (edgeHeader) {')


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def prepared_shell(base_shell: str, has_update1: bool) -> str:
    if base_shell.count(BASE_TOP) != 1:
        raise RuntimeError('Base shell top bar anchor is not unique')
    if has_update1:
        return base_shell.replace(BASE_TOP, UPDATE_1_TOP, 1)
    return base_shell


def apply_header_route(shell: str, has_update1: bool) -> str:
    if has_update1:
        marker = '} else if (edgeHeader) {'
        if shell.count(marker) != 1:
            raise RuntimeError('Expected Update 1 branch is missing or duplicated')
        return shell.replace(marker, '} else ' + HISTORY_BRANCH, 1)
    if shell.count(BASE_TOP) != 1:
        raise RuntimeError('Expected base top bar anchor missing')
    return shell.replace(BASE_TOP, 'if (showTopBar) {\n                ' + HISTORY_BRANCH, 1)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path)
    p.add_argument('--check', action='store_true', help='Validate compatibility without writing')
    args = p.parse_args()
    root = args.repository.resolve()
    if not (root / '.git').exists():
        raise RuntimeError('Destination is not a Git clone')
    head = git(root, 'rev-parse', 'HEAD')
    if head != BASE_SHA:
        raise RuntimeError(f'Wrong base commit. Expected {BASE_SHA}; found {head}')
    if not (root / SCREEN).is_file() or not (root / SHELL).is_file() or (root / HEADER).exists():
        raise RuntimeError('Missing required files or HistoryBrandedHeader already exists')
    if git(root, 'hash-object', str(root / SCREEN)) != BASE_SCREEN_BLOB:
        raise RuntimeError('Existing RiwayatScreen.kt no longer matches verified base')
    if git(root, 'status', '--porcelain', '--', str(SCREEN)):
        raise RuntimeError('RiwayatScreen.kt has existing changes; refusing to overwrite')

    base_shell = git(root, 'show', f'HEAD:{SHELL.as_posix()}')
    actual = (root / SHELL).read_text(encoding='utf-8').strip()
    pristine = prepared_shell(base_shell, has_update1=False)
    after_update1 = prepared_shell(base_shell, has_update1=True)
    if actual == pristine:
        has_update1 = False
    elif actual == after_update1:
        has_update1 = True
    else:
        raise RuntimeError('MainDashboardScreen.kt has other changes; manual merge required')

    bundled = Path(__file__).resolve().parent / 'files'
    for relative in (SCREEN, HEADER):
        if not (bundled / relative).is_file():
            raise RuntimeError(f'Missing bundled file: {relative}')
    updated_shell = apply_header_route(actual, has_update1)
    if updated_shell.count('HistoryBrandedHeader(') != 1:
        raise RuntimeError('New history header is not wired exactly once')

    if args.check:
        print('PASS: base SHA, Riwayat source, header routing, assets compatible; nothing written')
        return
    (root / SHELL).write_text(updated_shell + '\n', encoding='utf-8')
    shutil.copy2(bundled / SCREEN, root / SCREEN)
    shutil.copy2(bundled / HEADER, root / HEADER)
    print('Applied Update 3 Riwayat UI locally; 3 source files affected.')
    print('GitHub push: NO; Git commit: NO; APK build: NO.')
    print(git(root, 'status', '--short', '--', str(SHELL), str(SCREEN), str(HEADER)))


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
