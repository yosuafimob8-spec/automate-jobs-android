#!/usr/bin/env python3
"""Apply Updates 1, 2, 3, 5, 6 and 7 to the exact verified base (local only)."""
import argparse
from pathlib import Path
import subprocess
import sys


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path)
    p.add_argument('--check', action='store_true')
    args = p.parse_args()
    folder = Path(__file__).resolve().parent
    scripts = [folder / 'update1-pro' / 'apply_patch.py',
               folder / 'update2-workpedia' / 'apply_update2.py',
               folder / 'update3-history' / 'apply_update3.py',
               folder / 'update5-certificate' / 'apply_update5.py',
               folder / 'update6-kirim-lamaran' / 'apply_update6.py',
               folder / 'update7-surat-lamaran' / 'apply_update7.py']
    # For --check, simulate the correct sequence on a temporary worktree? Existing
    # update scripts verify no overlapping edits; UPDATE 3 accepts either base or
    # Update 1 shell. All six are individually preflighted before writing.
    for script in scripts:
        subprocess.run([sys.executable, str(script), str(args.repository), '--check'], check=True)
    if args.check:
        print('Updates 1, 2, 3, 5, 6, 7 compatible with verified base; no files changed.')
        return
    for script in scripts:
        subprocess.run([sys.executable, str(script), str(args.repository)], check=True)
    print('Updates 1, 2, 3, 5, 6, 7 applied to local clone. No GitHub push or APK build.')


if __name__ == '__main__':
    main()
