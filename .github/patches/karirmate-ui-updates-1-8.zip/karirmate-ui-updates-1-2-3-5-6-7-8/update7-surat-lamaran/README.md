# KarirMate UI Update 7 — Surat Lamaran & Resign

**Base terverifikasi:** GitHub Actions run `42179122453`, commit `1b4c04b6e3d13196b927d556a4394ae21f0a3a42`.

**Perubahan hanya UI dan navigasi:**
- Header gradasi biru berbentuk melengkung seperti referensi, logo K, tombol kembali, judul, subjudul, badge PRO/FREE mengikuti status akun.
- Hero *Surat Karier*: label KARIRMATE, PUSAT KARIER, ilustrasi surat, dan Info expand/collapse.
- Card Surat Lamaran Otomatis dengan CTA asli ke CV Builder.
- Form Surat Pengunduran Diri dengan 6 field bergambar, tanggal manual atau pemilih tanggal Android, tombol Buat Draf Resign.
- Tetap gunakan `CareerLetters.resignation`, editor surat, `CvRenderer.letterPages`, pratinjau A4 dan ekspor PDF yang sudah ada.
- Navigasi bawah dan halaman lain tetap. Tidak mengubah header Sertifikat (Update 5).

**Cara menggunakan pada clone lokal yang masih berada tepat pada commit base:**

```bash
python3 /path/to/karirmate-update7-surat-lamaran/apply_update7.py "$PWD" --check
python3 /path/to/karirmate-update7-surat-lamaran/apply_update7.py "$PWD"
```

`--check` tidak menulis apa pun, dan apply hanya menyunting working tree lokal. **Tidak ada push/commit/build APK**. Belum diuji kompilasi Compose, emulator, maupun akurasi visual pixel-perfect.
