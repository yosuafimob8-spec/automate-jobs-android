#!/usr/bin/env python3
"""Apply Update 7 (Surat Lamaran & Resign UI) locally against run 42179122453.

No GitHub mutation, commit, GitHub Actions trigger, or APK/Gradle build.
Can be applied alone or after Updates 1/2/3/5/6.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

BASE_SHA = '1b4c04b6e3d13196b927d556a4394ae21f0a3a42'
SCREENS = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')
SHELL = SCREENS / 'MainDashboardScreen.kt'
ORIGINAL = SCREENS / 'CareerToolsScreens.kt'
HEADER = SCREENS / 'CareerLettersBrandedHeader.kt'
BODY = SCREENS / 'CareerLettersRedesignedScreen.kt'
OLD_ROUTE = 'composable(Screen.CareerLetters.route) {\n                CareerLettersScreen(onApplicationLetter = {'
NEW_ROUTE = 'composable(Screen.CareerLetters.route) {\n                CareerLettersRedesignedScreen(onApplicationLetter = {'
HEADER_MARKER = '} else if (edgeHeader) {'
HEADER_INSERT = '''} else if (currentRoute == Screen.CareerLetters.route) {
                    CareerLettersBrandedHeader(
                        isPro = isPro,
                        onBack = onBack ?: navigateUpOrDashboard
                    )
                } else if (edgeHeader) {'''


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def replace_once(source: str, before: str, after: str, label: str) -> str:
    count = source.count(before)
    if count != 1:
        raise RuntimeError(f'{label}: expected 1 exact match, got {count}. No changes made.')
    return source.replace(before, after, 1)


def transform(shell: str) -> str:
    updated = replace_once(shell, OLD_ROUTE, NEW_ROUTE, 'Kotlin route')
    updated = replace_once(updated, HEADER_MARKER, HEADER_INSERT, 'TopBar header routing')
    if updated.count('CareerLettersBrandedHeader(') != 1 or updated.count('CareerLettersRedesignedScreen(') != 1:
        raise RuntimeError('Expected exactly one custom header and one screen route')
    return updated


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path, help='Exact local Git clone of run 42179122453 base')
    p.add_argument('--check', action='store_true', help='Only validate, make no changes')
    args = p.parse_args()
    root = args.repository.resolve()
    if not (root / '.git').exists():
        raise RuntimeError('Target must be local Git clone; GitHub repository is NOT modified.')
    sha = git(root, 'rev-parse', 'HEAD')
    if sha != BASE_SHA:
        raise RuntimeError(f'Wrong base commit: {sha}; expected {BASE_SHA}.')
    for rel in (SHELL, ORIGINAL):
        if not (root / rel).is_file():
            raise RuntimeError(f'Missing source file {rel}')
    for rel in (HEADER, BODY):
        if (root / rel).exists():
            raise RuntimeError(f'File already exists; patch may already be applied: {rel}')
    source = Path(__file__).resolve().parent / 'files'
    for rel in (HEADER, BODY):
        if not (source / rel).is_file():
            raise RuntimeError(f'Missing Kotlin patch file {rel}')
    # Keep existing generator untouched; only UI routing and new UI components change.
    old = (root / ORIGINAL).read_text(encoding='utf-8')
    for anchor in ('fun CareerLettersScreen(onApplicationLetter:', 'CareerLetters.resignation(',
                   'CvRenderer.letterPages(content)', 'PdfExportButton(pages,'):
        if anchor not in old:
            raise RuntimeError('Existing letter-generation contract is unexpected: ' + anchor)
    component = (source / BODY).read_text(encoding='utf-8')
    for anchor in ('CareerLetters.resignation(', 'CvRenderer.letterPages(content)',
                   'PdfExportButton(pages,', 'onApplicationLetter', 'rememberDatePickerState('):
        if anchor not in component:
            raise RuntimeError('New UI missing functional contract: ' + anchor)
    original_shell = (root / SHELL).read_text(encoding='utf-8')
    patched_shell = transform(original_shell)
    if args.check:
        print('PASS Update 7: base SHA, page route, header branch, original PDF/letter logic and new UI assets checked. No writes.')
        return
    (root / SHELL).write_text(patched_shell, encoding='utf-8')
    for rel in (HEADER, BODY):
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / rel, dst)
    print('Update 7 applied to local working tree only. No commit/push/build.')
    print(git(root, 'status', '--short', '--', *(str(i) for i in (SHELL, HEADER, BODY))))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
