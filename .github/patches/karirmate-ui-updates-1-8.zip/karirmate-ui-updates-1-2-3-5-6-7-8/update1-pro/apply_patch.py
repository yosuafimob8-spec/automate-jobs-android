#!/usr/bin/env python3
"""Apply KarirMate PRO redesign to the exact source used by Actions run 42179122453.
No git push, commit, Gradle build, or network activity is performed.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

BASE_SHA = "1b4c04b6e3d13196b927d556a4394ae21f0a3a42"
BASE_REL = Path("app/src/main/java/com/example/automatesmartbot/ui/screens")
TEST_REL = Path("app/src/test/java/com/example/automatesmartbot/ui/screens/SubscriptionUiTest.kt")
SHELL_REL = BASE_REL / "MainDashboardScreen.kt"
SUB_REL = BASE_REL / "SubscriptionScreens.kt"


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def change_once(s: str, old: str, new: str, name: str) -> str:
    count = s.count(old)
    if count != 1:
        raise RuntimeError(f"{name}: expected one exact base match, found {count}")
    return s.replace(old, new, 1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="Path to local automate-jobs-android clone")
    parser.add_argument("--check", action="store_true", help="Validate compatibility only; write nothing")
    args = parser.parse_args()
    root = args.repo.resolve()
    if not (root / ".git").exists():
        raise RuntimeError(f"Not a Git repository: {root}")
    current = git(root, "rev-parse", "HEAD")
    if current != BASE_SHA:
        raise RuntimeError(f"Wrong base commit. Expected {BASE_SHA}; got {current}. No files changed.")

    source = Path(__file__).resolve().parent / "files"
    additions = [
        BASE_REL / "ProUpgradeScreen.kt",
        BASE_REL / "ProBrandedHeader.kt",
        Path("app/src/main/res/drawable-nodpi/karirmate_pro_hero_art.png"),
    ]
    originals = [SUB_REL, SHELL_REL, TEST_REL]
    for file in originals:
        if not (root / file).is_file():
            raise RuntimeError(f"Missing base file: {file}")
        if git(root, "status", "--porcelain", "--", str(file)):
            raise RuntimeError(f"Local file already edited: {file}; patch not applied")
    for file in additions:
        if (root / file).exists():
            raise RuntimeError(f"Patch target already exists: {file}; patch not applied")
        if not (source / file).exists():
            raise RuntimeError(f"Patch package missing: {file}")

    old = {file: (root / file).read_text(encoding="utf-8") for file in originals}
    subscription = old[SUB_REL]
    start_marker = "@Composable\nfun UpgradeProScreen(onCheckout: (Int) -> Unit) {"
    next_marker = "@Composable\nfun ProCheckoutScreen("
    if subscription.count(start_marker) != 1 or subscription.count(next_marker) != 1:
        raise RuntimeError("SubscriptionScreens.kt: base composable marker mismatch")
    start = subscription.index(start_marker)
    end = subscription.index(next_marker, start)
    subscription = subscription[:start] + subscription[end:]

    shell = change_once(
        old[SHELL_REL],
        "if (showTopBar) {\n                if (edgeHeader) {",
        "if (showTopBar) {\n                if (currentRoute == Screen.UpgradePro.route) {\n"
        "                    ProBrandedHeader(onBack = onBack ?: navigateUpOrDashboard)\n"
        "                } else if (edgeHeader) {",
        "MainDashboardScreen.kt topBar"
    )
    test = change_once(
        old[TEST_REL],
        'compose.onNodeWithText("Pilih paket Bulanan").performScrollTo().performClick()',
        'compose.onNodeWithContentDescription("Pilih paket Bulanan").performScrollTo().performClick()',
        "SubscriptionUiTest.kt package button"
    )
    test = change_once(
        test,
        'compose.onNodeWithText("Upgrade KarirMate PRO").assertExists()',
        'compose.onNodeWithText("KarirMate PRO").assertExists()',
        "SubscriptionUiTest.kt hero label"
    )
    changes = {SUB_REL: subscription, SHELL_REL: shell, TEST_REL: test}
    if args.check:
        print("PASS: exact source base, 3 code changes and 3 added assets validated; nothing written")
        return 0
    for relative, content in changes.items():
        (root / relative).write_text(content, encoding="utf-8")
    for relative in additions:
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / relative, destination)
    print("Applied: PRO UI redesign (local working tree only).")
    print("GitHub push: NOT performed; APK build: NOT performed.")
    print(git(root, "status", "--short", "--", *(str(f) for f in originals + additions)))
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
