# KarirMate — Paket PRO UI Redesign

Base source: GitHub Actions run `42179122453`, branch
`integration/base41860101825-ui-merge-20261105`, commit
`1b4c04b6e3d13196b927d556a4394ae21f0a3a42`.

## Changes

- Replaces the old single-column PRO subscription list with the mockup-inspired
  blue promotional hero, 2x2 benefits and four selectable plan cards.
- Adds one native-blue/teal `ProBrandedHeader` modeled on AI Interview:
  integrated status bar, wave graphic, one Back button, K logo, vertical divider,
  `Paket PRO`, subtitle, and one gold PRO badge.
- Prevents the global AppTopBar from showing over the PRO page.
- Preserves the existing checkout/activation/store backend and bottom navigation.
- Keeps the demo-payment disclosure; no actual payment is activated.
- Updates the two text queries in SubscriptionUiTest to match the new UI.

## Apply (locally, no push/build)

From within your local repository **checked out at exactly the base commit**:

```bash
python3 /path/to/karirmate-pro-ui-patch/apply_patch.py "$PWD" --check
python3 /path/to/karirmate-pro-ui-patch/apply_patch.py "$PWD"
```

The script modifies only your working tree. It deliberately refuses a different
base SHA, dirty destination files, or already existing patch files.

No `git push`, `git commit`, `gradle`, `./gradlew` or workflow dispatch is included.
Build and visual validation are intentionally pending explicit permission.
