#!/usr/bin/env python3
"""Apply all 7 requested UI patches (#1 #2 #3 #5 #6 #7 #8) on a local Git clone.

No commit, push, GitHub Actions, or APK build.
"""
import argparse
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repository', type=Path)
    p.add_argument('--check', action='store_true')
    args = p.parse_args()
    folder = Path(__file__).resolve().parent
    old = folder / 'apply_updates_1_through_7.py'
    new = folder / 'update8-membership' / 'apply_update8.py'
    root = str(args.repository.resolve())
    # An all-or-nothing preflight prior to writing on fresh clones.
    subprocess.run([sys.executable, str(old), root, '--check'], check=True)
    subprocess.run([sys.executable, str(new), root, '--check'], check=True)
    if args.check:
        print('PASS: static compatibility checks complete, no files changed.')
        return
    subprocess.run([sys.executable, str(old), root], check=True)
    subprocess.run([sys.executable, str(new), root], check=True)
    print('All updates applied to local working tree. No push, commit, workflow or APK build.')

if __name__ == '__main__':
    main()
