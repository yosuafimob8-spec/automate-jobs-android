#!/usr/bin/env python3
"""Apply KarirMate revisions #5, #6, #7, #8 and #9 to a LOCAL checked-out integration branch.
No remote GitHub push and no APK build. Performs all changes in a sandbox first.
"""
from pathlib import Path
import subprocess
import shutil
import tempfile
import sys
import os

EXPECTED_BRANCH = 'integration/base41860101825-ui-merge-20261105'
HERE = Path(__file__).resolve().parent
KOTLIN = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')
TARGETS = [
    KOTLIN / 'JobTrainingScreen.kt',
    KOTLIN / 'AiInterviewScreen.kt',
    KOTLIN / 'MainDashboardScreen.kt',
    KOTLIN / 'LatihanPsikotesScreen.kt',
    KOTLIN / 'CareerToolsScreens.kt',
    Path('app/src/test/java/com/example/automatesmartbot/ui/screens/ElevenBugUiTest.kt'),
]
ADD = [
    KOTLIN / 'AiInterviewLanding.kt',
    KOTLIN / 'PsychotestHome.kt',
    KOTLIN / 'CareerEdgeHeader.kt',
    Path('app/src/main/res/drawable-nodpi/ai_interview_hr_portrait.webp'),
]


def verify(base: Path):
    screens = base / KOTLIN
    training = (screens / 'JobTrainingScreen.kt').read_text(encoding='utf-8-sig')
    ai = (screens / 'AiInterviewScreen.kt').read_text(encoding='utf-8-sig')
    navigation = (screens / 'MainDashboardScreen.kt').read_text(encoding='utf-8-sig')
    landing = (screens / 'AiInterviewLanding.kt').read_text(encoding='utf-8-sig')
    checks = {
        'Sertifikat: riwayat dan verifikasi': all(x in training for x in ['Syarat Mendapatkan Sertifikat', 'Periksa Sertifikat', 'Sertifikat Terbaru']),
        'Pelatihan: kategori dan level': all(x in training for x in ['Pilih Kategori Pelatihan', 'Level Pelatihan', 'Lanjutkan']),
        'AI: landing baru': 'InterviewModeLanding(' in ai and 'InterviewBrandedHeader(' in ai,
        'AI: pilihan mode teks': 'interviewMode = "text"; showPreparation = true' in ai,
        'AI: pilihan mode suara': 'interviewMode = "voice"; showPreparation = true' in ai,
        'AI: header tunggal': 'currentRoute != Screen.AiInterview.route' in navigation,
        'AI: kembali bertahap': 'report.isNotBlank() ->' in ai and 'showPreparation -> showPreparation = false' in ai,
        'AI: tanpa kembali ganda': not any(x in ai for x in ['← Pilih Interviewer', '←  Hasil Interview', 'Text("‹", modifier = Modifier.clickable']),
        'AI: backend/voice tetap ada': all(x in ai for x in ['requestInterview(', 'TextToSpeech', 'RecognizerIntent', 'send("start", emptyList())']),
        'AI: komponen Compose terpasang': 'internal fun InterviewModeLanding(' in landing,
        'AI: gambar HR tersedia': (base / ADD[2]).is_file(),
        'Sertifikat: tidak ada tombol kembali katalog': 'Kembali ke Katalog' not in training,
        'Psikotes: landing dirancang ulang': 'PsychotestHome(' in (screens / 'LatihanPsikotesScreen.kt').read_text(encoding='utf-8-sig'),
        'Psikotes: kartu Teks/CPNS nyata': all(x in (screens / 'PsychotestHome.kt').read_text(encoding='utf-8-sig') for x in ['Tes Kerja Swasta', 'Persiapan CPNS']),
        'Psikotes: satu tombol kembali': 'onBackActionChanged' in (screens / 'LatihanPsikotesScreen.kt').read_text(encoding='utf-8-sig') and 'psychotestBack' in navigation,
        'Psikotes: tombol kembali ganda dihapus': '← Kembali ke Psikotes' not in (screens / 'LatihanPsikotesScreen.kt').read_text(encoding='utf-8-sig'),
        'Kalkulator: tombol simulasi aktif': 'onClick = ::example' in (screens / 'CareerToolsScreens.kt').read_text(encoding='utf-8-sig'),
        'Kalkulator: hasil lengkap': all(x in (screens / 'CareerToolsScreens.kt').read_text(encoding='utf-8-sig') for x in ['Gaji diterima per bulan', 'Estimasi PPh 21 tahunan', 'Estimasi THR bruto']),
        'Kalkulator: input uang numerik': 'KeyboardType.Number' in (screens / 'CareerToolsScreens.kt').read_text(encoding='utf-8-sig'),
        'Header Edge-to-Edge tersedia': (screens / 'CareerEdgeHeader.kt').is_file(),
        'Header Edge-to-Edge di 4 rute': 'edgeHeaderRoutes' in navigation and 'CareerEdgeHeader(' in navigation,
        'Navigasi Pelatihan berurutan': 'backOneStage()' in training and 'onBackActionChanged' in training,
        'Kalkulator: tes baru': 'quickSimulationButtonCalculatesAfterEditsAndErrors' in (base / TARGETS[-1]).read_text(encoding='utf-8-sig'),
    }
    for name, passed in checks.items():
        print(('OK  ' if passed else 'FAIL') + name)
    if not all(checks.values()):
        raise RuntimeError('Validasi integrasi source gagal. Tidak ada file tujuan yang diubah.')


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Penggunaan: python3 apply_all.py /path/ke/automate-jobs-android')
    repo = Path(sys.argv[1]).expanduser().resolve()
    if not (repo / '.git').exists():
        raise SystemExit('ERROR: harus menunjuk folder root clone Git KarirMate yang valid.')
    branch = subprocess.run(['git', '-C', str(repo), 'branch', '--show-current'], capture_output=True, text=True, check=True).stdout.strip()
    if branch != EXPECTED_BRANCH:
        raise SystemExit(f'ERROR: branch aktif {branch!r}, wajib {EXPECTED_BRANCH!r}. Tidak ada perubahan.')
    for rel in TARGETS:
        if not (repo / rel).is_file():
            raise SystemExit(f'ERROR: file sumber tidak ditemukan: {rel}')
    for rel in ADD:
        if not (HERE / rel).is_file():
            raise SystemExit(f'ERROR: aset revisi tidak ditemukan: {rel}')

    with tempfile.TemporaryDirectory(prefix='karirmate_05_06_07_08_09_') as tempdir:
        stage = Path(tempdir)
        for rel in TARGETS:
            dst = stage / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(repo / rel, dst)
        for rel in ADD:
            dst = stage / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(HERE / rel, dst)
        for patch in ('apply_revisi_05.py', 'apply_revisi_06.py', 'apply_revisi_07.py', 'apply_revisi_08.py', 'apply_revisi_09.py', 'apply_revisi_10.py'):
            print('Menjalankan', patch)
            subprocess.run([sys.executable, str(HERE / patch), str(stage)], check=True)
        verify(stage)
        # Stage has passed all checks. Back up any destination before overwrite.
        for rel in TARGETS + ADD:
            dest = repo / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                backup = dest.with_suffix(dest.suffix + '.sebelum-revisi-05-06-07-08-09.bak')
                if not backup.exists():
                    shutil.copy2(dest, backup)
            tmp = dest.with_name(dest.name + '.karirmate-tmp')
            shutil.copy2(stage / rel, tmp)
            os.replace(tmp, dest)
    print('\nSELESAI: Revisi #5, #6, #7, #8, #9 terintegrasi pada source LOKAL')
    print('Branch:', branch)
    print('Tidak push GitHub. Tidak build APK. Tidak mengklaim pengujian runtime/Gradle.')


if __name__ == '__main__':
    main()
