#!/usr/bin/env python3
"""Apply AI Interview visual redesign locally to a KarirMate checkout.
No GitHub push or APK build is performed. Usage: python3 apply_revision_07.py /path/to/automate-jobs-android
"""
import sys
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit('Pakai: python3 apply_revision_07.py /path/ke/automate-jobs-android')
repo = Path(sys.argv[1]).expanduser().resolve()
ai = repo / 'app/src/main/java/com/example/automatesmartbot/ui/screens/AiInterviewScreen.kt'
nav = repo / 'app/src/main/java/com/example/automatesmartbot/ui/screens/MainDashboardScreen.kt'
if not ai.is_file() or not nav.is_file():
    raise SystemExit('ERROR: path proyek KarirMate tidak ditemukan atau file layar tidak tersedia.')

def exactly(s, old, new, label):
    if s.count(old) != 1:
        raise RuntimeError(f'Perubahan dibatalkan: pola {label} tidak cocok (jumlah {s.count(old)}).')
    return s.replace(old,new,1)

original_ai = ai.read_text(encoding='utf-8-sig')
original_nav = nav.read_text(encoding='utf-8-sig')

s = original_ai
s = exactly(s, 'fun AiInterviewScreen(isPro: Boolean = false) {',
    'fun AiInterviewScreen(isPro: Boolean = false, onExit: () -> Unit = {}) {', 'API AI screen')

intro_start='    if (!started && !showPreparation && report.isBlank()) {'
intro_end='    } else if (!started && report.isBlank()) {'
a=s.find(intro_start)
b=s.find(intro_end,a)
if a < 0 or b < 0:
    raise RuntimeError('Perubahan dibatalkan: blok halaman pilihan mode tidak ditemukan.')

# Preserve the existing backend, voice, CV, session, and result logic untouched.
# Only replace landing UI and host its own single back control.
redesign = '''    Column(Modifier.fillMaxSize()) {
        InterviewBrandedHeader(
            isPro = isPro,
            onBack = {
                when {
                    report.isNotBlank() -> {
                        report = ""; started = false; showPreparation = true; tts.stop()
                    }
                    started -> { started = false; showPreparation = true; tts.stop() }
                    showPreparation -> showPreparation = false
                    else -> onExit()
                }
            }
        )
        Box(Modifier.weight(1f)) {
            if (!started && !showPreparation && report.isBlank()) {
                InterviewModeLanding(
                    onTextSelected = { interviewMode = "text"; showPreparation = true },
                    onVoiceSelected = { interviewMode = "voice"; showPreparation = true }
                )
'''
s=s[:a]+redesign+s[b:]
# Remove duplicate in-content back controls; the branded header is the only visual back button.
s=exactly(s,
    'Text("← Pilih Interviewer", modifier = Modifier.clickable { showPreparation = false }, color = orange,\n                fontWeight = FontWeight.Bold, fontSize = 18.sp)',
    'Text("Persiapan Interview", color = ink, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)',
    'preparation duplicate back')
s=exactly(s,
    'Text("←  Hasil Interview", modifier = Modifier.clickable { report = ""; started = false; showPreparation = true }, color = orange,\n                fontWeight = FontWeight.Bold, fontSize = 18.sp)',
    'Text("Hasil Interview", color = ink, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)',
    'result duplicate back')
s=exactly(s,
    '                Text("‹", modifier = Modifier.clickable { started = false; showPreparation = true; tts.stop() }, color = ink, style = MaterialTheme.typography.headlineMedium)\n                Spacer(Modifier.width(12.dp))\n',
    '', 'active-session duplicate back')
# Close the newly opened Box and Column; original end closes the inner interview branch and the function.
end='\n    }\n}\n'
if not s.endswith(end):
    raise RuntimeError('Perubahan dibatalkan: penutup fungsi AI berubah.')
s=s[:-len(end)]+'\n    }\n        }\n    }\n}\n'

n=original_nav
n=exactly(n,
    'val showTopBar = currentRoute in appShellRoutes && currentRoute != Screen.Dashboard.route',
    'val showTopBar = currentRoute in appShellRoutes && currentRoute != Screen.Dashboard.route && currentRoute != Screen.AiInterview.route',
    'hide duplicate global top bar')
n=exactly(n,
    'AiInterviewScreen(isPro = isPro)',
    'AiInterviewScreen(isPro = isPro, onExit = navigateUpOrDashboard)',
    'wire AI screen exit')

# All validation precedes writing. Keep backups for easy reversal.
for file in (ai,nav):
    backup=file.with_suffix(file.suffix+'.before-revisi07.bak')
    if not backup.exists():
        shutil.copy2(file,backup)
ai.write_text(s,encoding='utf-8')
nav.write_text(n,encoding='utf-8')
for relative in ('app/src/main/java/com/example/automatesmartbot/ui/screens/AiInterviewLanding.kt',
                 'app/src/main/res/drawable-nodpi/ai_interview_hr_portrait.webp'):
    dest=repo/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(BASE/relative,dest)
print('BERHASIL: Revisi #7 diterapkan pada source lokal:', repo)
print('UI AI Interview: header tunggal, landing sesuai referensi, mode teks dan suara terhubung ke alur lama.')
print('Belum build APK, belum push GitHub, belum menguji layanan AI.')
