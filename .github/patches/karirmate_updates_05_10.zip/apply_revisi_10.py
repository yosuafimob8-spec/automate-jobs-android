#!/usr/bin/env python3
"""Edge-to-edge branded top bar for Psikotes, Salary, Job Training and Certificates."""
from pathlib import Path
import sys
root=Path(sys.argv[1]); scr=root/'app/src/main/java/com/example/automatesmartbot/ui/screens'
p=scr/'MainDashboardScreen.kt'; n=p.read_text(encoding='utf-8-sig')
t=scr/'JobTrainingScreen.kt'; s=t.read_text(encoding='utf-8-sig')
def once(x,old,new,what):
    c=x.count(old)
    if c!=1: raise RuntimeError(f'{what}: expected 1, got {c}')
    return x.replace(old,new,1)
# Parent toolbar routes all use the same blue/mint gradient including transparent status bar.
n=once(n,'import androidx.compose.material3.Scaffold','import androidx.compose.material3.Scaffold\nimport androidx.compose.foundation.isSystemInDarkTheme','inset import')
n=once(n,'    val cvBack: () -> Unit = { if (!cvViewModel.goBack()) navigateUpOrDashboard() }', '''    val cvBack: () -> Unit = { if (!cvViewModel.goBack()) navigateUpOrDashboard() }
    var trainingBack by remember { mutableStateOf<(() -> Unit)?>(null) }
    val edgeHeaderRoutes = setOf(
        Screen.LatihanPsikotes.route, Screen.SalaryCalculator.route,
        Screen.JobTraining.route, Screen.Certificates.route
    )
    val edgeHeader = currentRoute in edgeHeaderRoutes''', 'add new routes')
anchor='        currentRoute == Screen.LatihanPsikotes.route -> { { psychotestBack?.invoke() ?: navigateUpOrDashboard() } }'
n=once(n,anchor,anchor+'\n        currentRoute == Screen.JobTraining.route || currentRoute == Screen.Certificates.route -> { { trainingBack?.invoke() ?: navigateUpOrDashboard() } }','training back')
old='''                AppTopBar(
                    title = currentTitle,
                    isPro = isPro,
                    onNavigateProfil = {
                        navController.navigate(Screen.Profil.route) {
                            launchSingleTop = true
                        }
                    },
                    onBack = onBack
                )'''
new='''                if (edgeHeader) {
                    CareerEdgeHeader(
                        title = currentTitle,
                        subtitle = when (currentRoute) {
                            Screen.LatihanPsikotes.route -> "Latihan Tes Kerja & Persiapan CPNS"
                            Screen.SalaryCalculator.route -> "Simulasi gaji, lembur dan potongan"
                            Screen.JobTraining.route -> "Upgrade skill untuk dunia kerja"
                            else -> "Riwayat dan verifikasi sertifikat"
                        },
                        isPro = isPro,
                        onBack = onBack ?: navigateUpOrDashboard,
                        onProfile = { navController.navigate(Screen.Profil.route) { launchSingleTop = true } }
                    )
                } else {
                    AppTopBar(
                        title = currentTitle,
                        isPro = isPro,
                        onNavigateProfil = { navController.navigate(Screen.Profil.route) { launchSingleTop = true } },
                        onBack = onBack
                    )
                }'''
n=once(n,old,new,'parent topbar')
n=once(n,'composable(Screen.JobTraining.route) { JobTrainingScreen() }','composable(Screen.JobTraining.route) { JobTrainingScreen(onExit = navigateUpOrDashboard, onBackActionChanged = { trainingBack = it }) }','training call')
n=once(n,'composable(Screen.Certificates.route) { JobTrainingScreen(initialStage = "history") }','composable(Screen.Certificates.route) { JobTrainingScreen(initialStage = "history", onExit = navigateUpOrDashboard, onBackActionChanged = { trainingBack = it }) }','certificates call')
# Register one stage-aware back callback for both Android back gesture and single toolbar back button.
s=once(s,'fun JobTrainingScreen(initialStage: String = "catalog") {', '''fun JobTrainingScreen(
    initialStage: String = "catalog",
    onExit: () -> Unit = {},
    onBackActionChanged: ((() -> Unit)?) -> Unit = {}
) {''','training signature')
s=once(s,'    var stage by rememberSaveable(initialStage) { mutableStateOf(initialStage) }','''    var stage by rememberSaveable(initialStage) { mutableStateOf(initialStage) }
    fun backOneStage() {
        when (stage) {
            "catalog" -> onExit()
            "history" -> if (initialStage == "history") onExit() else stage = "catalog"
            "certificate" -> stage = "history"
            "positions" -> stage = "catalog"
            "modules" -> stage = "positions"
            "lesson", "practice", "exam", "result" -> stage = "modules"
            else -> stage = "catalog"
        }
    }
    DisposableEffect(stage, initialStage) {
        onBackActionChanged({ backOneStage() })
        onDispose { onBackActionChanged(null) }
    }
    androidx.activity.compose.BackHandler(enabled = stage != "catalog") { backOneStage() }''','training navigation')
start=s.index('            if (stage != "catalog" && initialStage != "history") TextButton(onClick = {')
end=s.index('            Text("▣ KarirMate"',start)
s=s[:start]+s[end:]
# Save only after all anchors match.
p.write_text(n,encoding='utf-8');t.write_text(s,encoding='utf-8')
print('OK Revisi #10: four route edge-to-edge headers and single back controls')
