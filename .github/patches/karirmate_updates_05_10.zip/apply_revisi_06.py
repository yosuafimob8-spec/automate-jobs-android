from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
p=root/'app/src/main/java/com/example/automatesmartbot/ui/screens/JobTrainingScreen.kt'
s=p.read_text(encoding='utf-8-sig')
start=s.index('                "catalog" -> {')
end=s.index('                "positions" -> {',start)
new='''                "catalog" -> {
                    val navy = darkTraining
                    val blue = Color(0xFF0866B5)
                    val categoryColors = listOf(
                        Color(0xFFE5F4FF), Color(0xFFF2E9FF), Color(0xFFE5FAF0),
                        Color(0xFFFFF2DF), Color(0xFFFFE9F0), Color(0xFFE4F8FC)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("🎓", fontSize = 48.sp)
                        Spacer(Modifier.width(10.dp))
                        Text("Pelatihan Kerja", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = navy, modifier = Modifier.weight(1f))
                        Text("▶ 📚", fontSize = 27.sp, color = blue)
                    }
                    val shortcuts = listOf(
                        Triple("📖", "Katalog\\nPelatihan", "catalog"),
                        Triple("▶️", "Lanjutkan\\nBelajar", "modules"),
                        Triple("🏅", "Sertifikat\\nSaya", "history"),
                        Triple("📊", "Riwayat\\nPelatihan", "history")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        shortcuts.forEach { (emoji, title, destination) ->
                            Card(
                                modifier = Modifier.weight(1f).height(114.dp).clickable {
                                    if (destination == "modules") choose(courseId)
                                    else stage = destination
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = ScreenSurface),
                                border = BorderStroke(1.dp, screenCanvas(Color(0xFFC6DFE8)))
                            ) {
                                Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(emoji, fontSize = 26.sp)
                                    Text(title, color = navy, fontWeight = FontWeight.Bold, fontSize = 11.sp, lineHeight = 14.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    Text("▱  Pilih Kategori Pelatihan", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = navy)
                    val groups = TrainingPositions.groups
                    groups.take(6).chunked(2).forEachIndexed { rowIndex, pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            pair.forEachIndexed { colIndex, group ->
                                val index = rowIndex * 2 + colIndex
                                val icon = listOf("💼", "💬", "🏭", "💻", "📣", "🎧")[index]
                                Card(
                                    modifier = Modifier.weight(1f).heightIn(min = 86.dp).clickable { selectedCategory = index; stage = "positions" },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = screenCanvas(categoryColors[index])),
                                    border = BorderStroke(1.dp, screenCanvas(Color(0xFFC6DFE8)))
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(icon, fontSize = 24.sp)
                                        Spacer(Modifier.width(7.dp))
                                        Text(group.category, fontSize = 12.sp, lineHeight = 15.sp, fontWeight = FontWeight.Bold, color = navy, modifier = Modifier.weight(1f))
                                        Text("›", fontSize = 23.sp, color = navy)
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    if (groups.size > 6) {
                        Text("Kategori lainnya", fontWeight = FontWeight.Bold, color = navy)
                        groups.drop(6).forEachIndexed { offset, group ->
                            OutlinedButton(onClick = { selectedCategory = offset + 6; stage = "positions" }, modifier = Modifier.fillMaxWidth()) {
                                Text(group.category, color = navy)
                            }
                        }
                    }
                    Text("🔥  Level Pelatihan", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = navy)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(Triple("🌱", "Basic", "Pemula"), Triple("📊", "Intermediate", "Menengah"), Triple("🏆", "Advance", "Mahir")).forEachIndexed { index, item ->
                            Card(
                                modifier = Modifier.weight(1f).height(110.dp).clickable {
                                    selectedLevel = TrainingLevel.entries[index].name
                                    stage = "positions"
                                },
                                colors = CardDefaults.cardColors(containerColor = screenCanvas(listOf(Color(0xFFE0F9EE), Color(0xFFE4F2FF), Color(0xFFF1E8FF))[index])),
                                border = BorderStroke(1.dp, screenCanvas(Color(0xFFC6DFE8))),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(Modifier.fillMaxSize().padding(5.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(item.first, fontSize = 25.sp)
                                    Text(item.second, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = navy)
                                    Text("(${item.third})", fontSize = 11.sp, color = navy)
                                }
                            }
                        }
                    }
                    Surface(shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, screenCanvas(Color(0xFFC6DFE8))), color = ScreenSurface) {
                        Text("ⓘ  Sertifikat penyelesaian adalah bukti latihan internal, bukan sertifikasi kompetensi resmi BNSP.", modifier = Modifier.fillMaxWidth().padding(14.dp), color = navy, fontSize = 13.sp)
                    }
                    Button(onClick = { stage = "history" }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = blue), shape = RoundedCornerShape(14.dp)) {
                        Text("▣  Lihat Riwayat Sertifikat  ›", fontWeight = FontWeight.Bold)
                    }
                }
'''
s=s[:start]+new+s[end:]
# Remove the duplicate internal back arrow on the training landing page; keep step-back for nested lesson stages until host navigation is wired.
# Existing shell top bar remains the sole back control on catalog.
p.write_text(s,encoding='utf-8')
print('Applied revision 6 to',p)
