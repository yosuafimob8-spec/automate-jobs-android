from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
p=root/'app/src/main/java/com/example/automatesmartbot/ui/screens/JobTrainingScreen.kt'
s=p.read_text(encoding='utf-8-sig')
old='''            if (stage != "catalog") TextButton(onClick = {'''
new='''            if (stage != "catalog" && initialStage != "history") TextButton(onClick = {'''
assert old in s;s=s.replace(old,new,1)
start=s.index('                "history" -> {')
end=s.index('\n            }\n        }\n    }',start)
replacement='''                "history" -> {
                    val history = JSONArray(prefs.getString("certificates", "[]"))
                    val latest = history.optJSONObject(history.length() - 1)
                    val ink = darkTraining
                    val blue = Color(0xFF0969B9)
                    val gold = Color(0xFFE5A728)
                    Text("Riwayat Sertifikat", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = ink)
                    Text("Kumpulan sertifikat pelatihan yang Anda peroleh di KarirMate.", color = ink, fontSize = 14.sp)
                    TrainingCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✦", fontSize = 32.sp, color = blue)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Syarat Mendapatkan Sertifikat", fontWeight = FontWeight.ExtraBold, color = ink)
                                Text("Selesaikan tahapan yang dipersyaratkan untuk program sertifikat terkait.", fontSize = 12.sp, color = ink)
                            }
                        }
                        listOf(
                            Triple("Psikotes", "Tes gabungan kepribadian, logika, numerik, dan verbal", "Status belum terhubung"),
                            Triple("Pelatihan Kerja", "Level Basic sampai Advance", if (latest != null) "Ada sertifikat pelatihan" else "Belum ada sertifikat"),
                            Triple("Interview AI", "Simulasi wawancara kerja", "Status belum terhubung")
                        ).forEach { (title, subtitle, status) ->
                            Surface(shape = RoundedCornerShape(12.dp), color = screenCanvas(Color(0xFFF0F7FC)), border = BorderStroke(1.dp, screenCanvas(Color(0xFFD2E3F0)))) {
                                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                    Text(title, fontWeight = FontWeight.Bold, color = ink)
                                    Text(subtitle, fontSize = 12.sp, color = ink)
                                    Text(status, fontSize = 12.sp, color = if (status.startsWith("Ada")) tealTraining else blue)
                                }
                            }
                        }
                        Text("Status tidak otomatis dianggap lulus. Sertifikat pelatihan bukan sertifikasi resmi BNSP.", fontSize = 11.sp, color = ink)
                    }
                    TrainingCard {
                        Text("★ Sertifikat Terbaru", color = blue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        if (latest == null) {
                            Text("Belum ada sertifikat. Selesaikan pelatihan untuk mendapatkannya.", color = ink)
                        } else {
                            Text(latest.optString("course", "Sertifikat Pelatihan"), fontWeight = FontWeight.Bold, color = ink)
                            Text("Nama: ${latest.optString("name", "-")}", color = ink)
                            Text("Tanggal terbit: ${latest.optString("date", "-")}", color = ink)
                            Text("Nomor sertifikat: ${latest.optString("id", "-")}", color = ink)
                            Text("Status: ${if (latest.optBoolean("serverRegistered")) "Terdaftar server" else "Tersimpan di perangkat; belum diverifikasi online"}", color = ink, fontSize = 12.sp)
                            Button(onClick = { certificate = latest; stage = "certificate" }, colors = ButtonDefaults.buttonColors(containerColor = blue)) {
                                Text("Lihat Sertifikat")
                            }
                            Text("Unduh PDF tersedia pada tampilan sertifikat. Bagikan setelah ekspor PDF melalui aplikasi berbagi Android.", fontSize = 12.sp, color = ink)
                        }
                    }
                    TrainingCard {
                        Text("Verifikasi Sertifikat", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = ink)
                        Text("Masukkan kode QR pada sertifikat untuk memeriksa identitas yang tersimpan di perangkat.", color = ink, fontSize = 12.sp)
                        var qrInput by rememberSaveable { mutableStateOf("") }
                        var qrFeedback by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = qrInput,
                            onValueChange = { qrInput = it; qrFeedback = "" },
                            label = { Text("Isi QR sertifikat") },
                            colors = karirInputColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = {
                            val known = (0 until history.length()).mapNotNull { index ->
                                val record = history.optJSONObject(index) ?: return@mapNotNull null
                                runCatching { TrainingCertificateIdentity.payload(
                                    record.optString("id"), record.optString("courseId"),
                                    record.optString("date"), record.optInt("score")
                                ) }.getOrNull()
                            }
                            qrFeedback = if (TrainingCertificateIdentity.verifyLocal(qrInput.trim(), known))
                                "Cocok dengan riwayat lokal. Belum merupakan verifikasi online."
                            else "Tidak ditemukan pada riwayat lokal perangkat ini."
                        }, colors = ButtonDefaults.buttonColors(containerColor = blue)) {
                            Text("Periksa Sertifikat")
                        }
                        if (qrFeedback.isNotBlank()) Text(qrFeedback, color = ink)
                    }
                    if (history.length() > 1) {
                        Text("Sertifikat Lainnya", fontWeight = FontWeight.Bold, color = ink)
                        (history.length() - 2 downTo 0).forEach { i ->
                            val item = history.optJSONObject(i) ?: return@forEach
                            TrainingCard {
                                Text(item.optString("course"), fontWeight = FontWeight.Bold, color = ink)
                                Text("${item.optString("name")} • ${item.optString("date")}", color = ink)
                                TextButton(onClick = { certificate = item; stage = "certificate" }) { Text("Lihat Sertifikat") }
                            }
                        }
                    }
                }'''
s=s[:start]+replacement+s[end:]
# Certificate detail returns to history via its one in-content button; top-level back in the host is sole back navigation on history.
p.write_text(s,encoding='utf-8')
print('Patched',p)
