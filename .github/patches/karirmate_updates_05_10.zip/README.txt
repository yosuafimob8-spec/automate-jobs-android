KarirMate — Paket Gabungan Revisi #5, #6, #7, #8, #9, #10
=====================================================
Branch TARGET: integration/base41860101825-ui-merge-20261105
JANGAN gunakan main.

ISI:
#5: Sertifikat — halaman riwayat dan verifikasi lokal
#6: Pelatihan Kerja — tampilan katalog, kategori, level
#7: AI Interview — pilihan Teks/Suara dan navigasi bertahap
#8: Psikotes — menu kerja swasta, CPNS, riwayat, statistik, PRO
#9: Kalkulator Gaji + Lembur — desain baru biru/putih, tombol Simulasi Cepat
     aktif, semua input mudah dibaca, input numerik mendukung titik pemisah
     ribuan, pilihan jenis hari lembur, bagian BPJS/PTKP/THR yang bisa dibuka,
     rincian hasil upah lembur, BPJS, PPh 21, THR, dan take-home pay.
     Menggunakan perhitungan existing PayrollCalculator; tidak mengubah rumus.
     Test UI kalkulator diperbarui mengikuti kontrol UI baru.

LANGKAH PENERAPAN DI FOLDER SOURCE LOKAL:
    unzip karirmate_revisi_05_06_07_08_09_gabungan.zip -d /tmp/karirmate_patch
    python3 /tmp/karirmate_patch/apply_all.py ~/automate-jobs-android

Skrip memeriksa branch aktif, melakukan backup semua file yang ditimpa,
menjalankan patch source pada direktori staging dahulu, dan menguji anchor
secara struktural sebelum menimpa file proyek.

BELUM DIPUSH KE GITHUB DAN BELUM DIBUILD.
Validasi struktural tidak sama dengan lulus build Android atau pengujian runtime.
Paket ini dibuat untuk diterapkan di checkout repo; tidak otomatis
mengubah aplikasi yang terpasang pada HP.

CATATAN HISTORIS:
- Psikotes & AI Interview membutuhkan backend aktif sesuai konfigurasi aplikasi.
- Gambar HR masih merupakan potongan screenshot referensi.
- Riwayat Pelatihan pada patch #6 belum memiliki storage khusus terpisah.
- Verifikasi sertifikat masih lokal (tidak diklaim valid secara online).
- Estimasi pajak bulanan belum mereplikasi TER bulanan aktual.

#10: Header edge-to-edge empat fitur, status bar Android transparan dengan ikon putih; tombol kembali tunggal bertahap.
