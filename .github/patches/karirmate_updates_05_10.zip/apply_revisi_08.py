#!/usr/bin/env python3
"""Apply revision 08 (Psikotes): landing redesign + single parent back action.
Only modifies a locally provided source checkout/staging folder; never GitHub.
"""
from pathlib import Path
import sys

SCREENS = Path('app/src/main/java/com/example/automatesmartbot/ui/screens')


def one_replace(source: str, old: str, new: str, tag: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'{tag}: expected 1 match, found {count}. Source has changed; do not overwrite.')
    return source.replace(old, new)


def apply(repo: Path):
    psych = repo / SCREENS / 'LatihanPsikotesScreen.kt'
    main = repo / SCREENS / 'MainDashboardScreen.kt'
    if not (psych.is_file() and main.is_file()):
        raise RuntimeError('Missing app Kotlin source; cannot patch Revisi 08.')
    s = psych.read_text(encoding='utf-8-sig')
    nav = main.read_text(encoding='utf-8-sig')
    s = one_replace(s,
        'fun LatihanPsikotesScreen(isPro: Boolean, onExit: () -> Unit = {}) {',
        'fun LatihanPsikotesScreen(isPro: Boolean, onExit: () -> Unit = {}, onBackActionChanged: ((() -> Unit)?) -> Unit = {}) {',
        'Psikotes parameter callback')
    s = one_replace(s,
        '    BackHandler { back() }',
        '''    // One back control: Android back and the existing parent app toolbar
    // both follow the same internal page history.
    DisposableEffect(page) {
        onBackActionChanged({ back() })
        onDispose { onBackActionChanged(null) }
    }
    BackHandler { back() }''',
        'Psikotes back action registration')
    start = s.find('            "home" -> LazyColumn(')
    end = s.find('            "catalog" -> Column(', start)
    if start < 0 or end < 0 or end <= start or 'CompactRoute(' not in s[start:end]:
        raise RuntimeError('Original home section not found. Will not modify source.')
    s = s[:start] + '''            "home" -> PsychotestHome(
                isPro = isPro,
                onPrivate = { family = "private"; page = "catalog" },
                onCpns = { family = "cpns"; page = "catalog" },
                onHistory = { vm.loadExtras(isPro); page = "history" },
                onStats = { if (isPro) { vm.loadExtras(isPro); page = "stats" } else proNotice = true },
                onLeaderboard = { if (isPro) { vm.loadExtras(isPro); page = "leaderboard" } else proNotice = true },
                onPro = { proNotice = true }
            )
''' + s[end:]
    # Remove duplicate back actions inside the content. Parent topbar has the sole back button.
    for old in (
        '                TextButton(onClick = { back() }, contentPadding = PaddingValues(0.dp)) { Text("← Kembali ke Psikotes", color = teal) }\n',
        '                item { TextButton(onClick = { back() }) { Text("← Kembali", color = teal) } }\n',
        '                TextButton(onClick = { page = "home" }) { Text("← Kembali", color = teal) }\n',
        '                item { TextButton(onClick = { page = "home" }) { Text("← Kembali", color = teal) } }\n',
    ):
        if s.count(old) != 1:
            raise RuntimeError(f'Duplicate back-button marker missing: {old.strip()[:65]}')
        s = s.replace(old, '')
    # Parent app toolbar already exists; wire it to the same local back function.
    nav = one_replace(nav,
        '    val onBack: (() -> Unit)? = if (!showBack) null else if (currentRoute == Screen.CvBuilder.route) cvBack else navigateUpOrDashboard',
        '''    var psychotestBack by remember { mutableStateOf<(() -> Unit)?>(null) }
    val onBack: (() -> Unit)? = when {
        !showBack -> null
        currentRoute == Screen.CvBuilder.route -> cvBack
        currentRoute == Screen.LatihanPsikotes.route -> { { psychotestBack?.invoke() ?: navigateUpOrDashboard() } }
        else -> navigateUpOrDashboard
    }''',
        'Parent back route')
    nav = one_replace(nav,
        'LatihanPsikotesScreen(isPro = isPro, onExit = navigateUpOrDashboard)',
        'LatihanPsikotesScreen(isPro = isPro, onExit = navigateUpOrDashboard, onBackActionChanged = { action -> psychotestBack = action })',
        'Parent Psikotes screen call')
    psych.write_text(s, encoding='utf-8')
    main.write_text(nav, encoding='utf-8')
    print('Revisi 08: Psikotes landing & toolbar back action patched.')

if __name__ == '__main__':
    if len(sys.argv) != 2: raise SystemExit('Usage: python3 apply_revisi_08.py <checkout-or-staging-root>')
    apply(Path(sys.argv[1]).resolve())
