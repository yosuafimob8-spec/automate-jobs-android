#!/usr/bin/env python3
"""Apply local UI-only salary calculator revision #9 and keep payroll formulas untouched."""
from pathlib import Path
import sys

ROOT=Path(sys.argv[1]).resolve()
HERE=Path(__file__).resolve().parent
p=ROOT/'app/src/main/java/com/example/automatesmartbot/ui/screens/CareerToolsScreens.kt'
s=p.read_text(encoding='utf-8-sig')
start= '// Revision #9: UI-only payroll calculator. Financial estimates use the existing PayrollCalculator.'
if start not in s:
    start='@Composable\nfun SalaryCalculatorScreen() {'
end='@Composable\nfun CareerLettersScreen(onApplicationLetter: () -> Unit) {'
assert s.count(start)>=1 and s.count(end)==1, 'Salary source anchors missing or ambiguous'
a=s.index(start); b=s.index(end)
assert a<b
fragment=(HERE/'salary_calculator_09_fragment.kt.txt').read_text(encoding='utf-8')
s=s[:a]+fragment+'\n'+s[b:]
assert 'import androidx.compose.ui.semantics.Role' in s
assert 'import androidx.compose.foundation.selection.selectable' in s
p.write_text(s,encoding='utf-8')

# Keep UI regression coverage meaningful with the new control names and numeric-only inputs.
t=ROOT/'app/src/test/java/com/example/automatesmartbot/ui/screens/ElevenBugUiTest.kt'
s=t.read_text(encoding='utf-8-sig')
start='    @Test fun quickSimulationCardAndButtonRecalculateAfterEditsAndErrors() {'
end='    @Test fun workpediaSearchFiltersAcceptsClearAndKeepsReadableInk() {'
assert s.count(end)==1 and (s.count(start)==1 or 'fun quickSimulationButtonCalculatesAfterEditsAndErrors()' in s), 'Salary test anchors missing or ambiguous'
a=s.index(start) if start in s else -1;b=s.index(end)
assert a < b if a != -1 else True
replacement='''    @Test fun quickSimulationButtonCalculatesAfterEditsAndErrors() {
        compose.setContent { KarirMateTheme(mode) { SalaryCalculatorScreen() } }
        val expected = PayrollCalculator.calculate(PayrollCalculator.Input(
            5000000, 5000000, 2, PayrollCalculator.OvertimeDay.WORKDAY,
            5000000, 5000000, 5000000, 54000000, 12, 5000000))
        val amount = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(expected.monthlyTakeHomeEstimate)
        bothModes {
            compose.onNodeWithText("Coba Simulasi Rp5.000.000").performScrollTo().performClick()
            input().performScrollTo().assertTextEquals("5000000")
            assertInputInk()
            compose.onNodeWithText("PERKIRAAN GAJI DITERIMA").performScrollTo().assertExists()
            compose.onAllNodesWithText(amount).assertCountEquals(2)
            input().performScrollTo().performTextReplacement("")
            compose.onNodeWithText("Hitung Estimasi Gaji").performScrollTo().performClick()
            compose.onNodeWithText("Isi nominal penghasilan dan dasar lembur terlebih dahulu.").performScrollTo().assertExists()
            compose.onNodeWithText("Coba Simulasi Rp5.000.000").performScrollTo().performClick()
            compose.onNodeWithText("Isi nominal penghasilan dan dasar lembur terlebih dahulu.").assertDoesNotExist()
            compose.onAllNodesWithText(amount).assertCountEquals(2)
            compose.onNodeWithText("Hari istirahat (5 hari kerja/minggu)").performScrollTo().performClick().assertIsSelected()
            compose.onNodeWithText("Coba Simulasi Rp5.000.000").performScrollTo().performClick()
            compose.onNodeWithText("Hari kerja biasa").performScrollTo().assertIsSelected()
        }
    }

    @Test fun everySalaryInputUsesReadableInkFocusedAndUnfocused() {
        lateinit var focus: FocusManager
        compose.setContent { KarirMateTheme(mode) { focus = LocalFocusManager.current; SalaryCalculatorScreen() } }
        compose.onNodeWithText("Atur BPJS, Pajak & THR  ▼").performScrollTo().performClick()
        bothModes {
            compose.onAllNodes(hasSetTextAction()).assertCountEquals(8)
            repeat(8) { index ->
                input(index).performScrollTo().performTextReplacement("123")
                assertInputInk(index)
                compose.runOnIdle { focus.clearFocus() }
                input(index).assertTextEquals("123")
                assertInputInk(index)
            }
        }
    }

'''
s=s[:a]+replacement+s[b:] if a != -1 else s
t.write_text(s,encoding='utf-8')
print('OK Revisi #9: Salary UI + regression tests patched in local staged source')
